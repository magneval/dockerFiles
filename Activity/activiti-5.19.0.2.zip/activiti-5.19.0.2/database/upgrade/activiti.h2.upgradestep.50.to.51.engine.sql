alter table ACT_RU_VARIABLE 
add TASK_ID_ varchar(64);
